package pt.ulisboa.tecnico.cmu.response;

public interface ResponseHandler {
	public void handle(HelloResponse hr);
}
